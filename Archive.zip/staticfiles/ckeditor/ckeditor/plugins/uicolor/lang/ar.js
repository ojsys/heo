﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ar",{title:"منتقي الألوان",preview:"معاينة مباشرة",config:"قص السطر إلى الملف config.js",predefined:"مجموعات ألوان معرفة مسبقا"});